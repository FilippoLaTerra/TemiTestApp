package com.lock.newtemiactionsystemtest.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.lock.newtemiactionsystemtest.ActionBuilderViewModel;
import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.actions.Action;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * @author Filippo La Terra Maggiore
 * @version 1.0
 * The ActionEditor is a generic view to hold the fragment for the specific fields to edit an action
 */
public class ActionEditor extends AppCompatActivity{

    Action actionToEdit;
    int actionPosition;
    ArrayList<Action> customTaskActions;
    Button buttonBack;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_editor);
        getSupportActionBar().hide();
        initViews();

        fragmentManager = getSupportFragmentManager();

        InitFragment();
        
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                finish();
            }
        });

    }

    /**
    * initializes the editor fragment of the Action
     */
    protected void InitFragment(){

        actionToEdit = (Action) getIntent().getSerializableExtra("action");
        actionPosition = (Integer) getIntent().getSerializableExtra("position");
        customTaskActions = (ArrayList<Action>) getIntent().getSerializableExtra("actionsList");

        Bundle args = new Bundle();
        args.putSerializable("action_key", actionToEdit);
        args.putSerializable("position_key", actionPosition);
        args.putSerializable("actionsList", customTaskActions);

        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerViewActionEditor, actionToEdit.Editor(), args)
                .setReorderingAllowed(true)
                .addToBackStack("")
                .commit();
    }

    private void initViews(){
        buttonBack = findViewById(R.id.buttonBack);
    }

}