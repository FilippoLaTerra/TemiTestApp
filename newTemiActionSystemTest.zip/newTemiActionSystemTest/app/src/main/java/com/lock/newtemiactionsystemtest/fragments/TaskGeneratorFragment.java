package com.lock.newtemiactionsystemtest.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.lock.newtemiactionsystemtest.ActionBuilderViewModel;
import com.lock.newtemiactionsystemtest.Activities.MainActivity;
import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.RecyclerViewInterface;
import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.actions.ActionModel;
import com.lock.newtemiactionsystemtest.actions.ActionModelRecycleViewAdapter;
import com.lock.newtemiactionsystemtest.actions.ActionRecyclerViewAdapter;
import com.lock.newtemiactionsystemtest.actions.MoveToLocationAction;
import com.lock.newtemiactionsystemtest.actions.SpeakMessageAction;
import com.lock.newtemiactionsystemtest.actions.changeTextAction;
import com.lock.newtemiactionsystemtest.helpers.TaskHelper;
import com.lock.newtemiactionsystemtest.tasks.Task;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TaskGeneratorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TaskGeneratorFragment extends Fragment implements RecyclerViewInterface {

    RecyclerView baseActionsRecyclerView, newTaskRecyclerView;
    ArrayList<ActionModel> baseActions = new ArrayList<>();
    ActionModelRecycleViewAdapter adapterActions;
    ActionRecyclerViewAdapter adapterTask;
    Button buttonSaveBuiltTask;
    ActionBuilderViewModel viewModel;
    TaskHelper taskHelper;


    public TaskGeneratorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TaskGeneratorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TaskGeneratorFragment newInstance(String param1, String param2) {
        TaskGeneratorFragment fragment = new TaskGeneratorFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        viewModel = new ViewModelProvider(requireActivity()).get(ActionBuilderViewModel.class);
        taskHelper = TaskHelper.getInstance();

        if (taskHelper.customTaskActions != null){
            viewModel.customTaskActions = taskHelper.customTaskActions;
        } else if (savedInstanceState != null) {
            viewModel.customTaskActions = (ArrayList<Action>) savedInstanceState.getSerializable("actions");
        }

        setBaseActionsList();

        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_task_generator, container, false);

        buttonSaveBuiltTask = view.findViewById(R.id.buttonSaveBuiltTask);

        baseActionsRecyclerView = view.findViewById(R.id.baseActionsRecyclerView);
        newTaskRecyclerView = view.findViewById(R.id.newTaskRecyclerView);

        LinearLayoutManager managerActions = new LinearLayoutManager(requireContext().getApplicationContext());
        LinearLayoutManager managerTask = new LinearLayoutManager(requireContext().getApplicationContext());
        baseActionsRecyclerView.setLayoutManager(managerActions);
        newTaskRecyclerView.setLayoutManager(managerTask);


        adapterActions = new ActionModelRecycleViewAdapter(requireContext().getApplicationContext(), baseActions, this);
        baseActionsRecyclerView.setAdapter(adapterActions);

        adapterTask = new ActionRecyclerViewAdapter(requireContext().getApplicationContext(), viewModel.customTaskActions, this);
        newTaskRecyclerView.setAdapter(adapterTask);

        buttonSaveBuiltTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                taskHelper.setTaskBuffer(new Task(0, viewModel.customTaskActions, "defaultname", null));
            }
        });

        return view;
    }

    private void setBaseActionsList(){
        int[] actiondID = getResources().getIntArray(R.array.actions_id);
        String[] actionsName = getResources().getStringArray(R.array.actions_name);
        String[] actionsDescription = getResources().getStringArray(R.array.actions_description);

        for (int i = 0; i < actiondID.length; i++) {

           baseActions.add(new ActionModel(actiondID[i], actionsName[i], actionsDescription[i]));
        }
    }

    @Override
    public void onItemClick(int position) {

        Action a;

        switch(baseActions.get(position).action_id){

            case 102:   a = new MoveToLocationAction();
                        break;
            case 103:   a = new SpeakMessageAction();
                        break;
            case 902:   a = new changeTextAction();
                        break;
            default:    a = new MoveToLocationAction();
                        break;
        }
        viewModel.customTaskActions.add(a);
        adapterTask.notifyItemChanged(viewModel.customTaskActions.size());
    }

    @Override
    public void onEditButtonClick(int position) {
        viewModel.actionToEditPosition = position;
        viewModel.customTaskActions.get(position).openEditor(requireContext().getApplicationContext(), (MainActivity)getActivity(), position, viewModel.customTaskActions);
    }

    @Override
    public void onInfoButtonClick(int position) {
        Log.i("birubiru", viewModel.customTaskActions.get(position).toString());
    }

    @Override
    public void onRemoveButtonClick(int position) {
        viewModel.customTaskActions.remove(position);
        adapterTask.notifyItemRemoved(position);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putSerializable("actions", viewModel.customTaskActions);
        super.onSaveInstanceState(outState);

    }

}