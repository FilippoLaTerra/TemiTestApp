package com.lock.newtemiactionsystemtest;

public interface ActionListenerInterface {
    void onComplete();
    void onError();
}
