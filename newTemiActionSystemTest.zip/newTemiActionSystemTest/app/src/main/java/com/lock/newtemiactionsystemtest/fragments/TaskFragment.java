package com.lock.newtemiactionsystemtest.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.lock.newtemiactionsystemtest.ActionBuilderViewModel;
import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.actions.changeTextAction;
import com.lock.newtemiactionsystemtest.helpers.TaskHelper;
import com.lock.newtemiactionsystemtest.tasks.Task;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TaskFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TaskFragment extends Fragment {

    Button buttonStartTask, buttonStartCustomTask;
    TextView log;
    TextView textViewText;
    ActionBuilderViewModel viewModel;
    TaskHelper taskHelper;
    public static TaskFragment newInstance(String task) {
        TaskFragment fragment = new TaskFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
    taskHelper = TaskHelper.getInstance();
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_task, container, false);
        log = view.findViewById(R.id.log);
        buttonStartTask = view.findViewById(R.id.buttonStartTask);
        buttonStartCustomTask = view.findViewById(R.id.buttonStartCustomTask);
        textViewText = view.findViewById(R.id.textViewText);
        viewModel = new ViewModelProvider(this).get(ActionBuilderViewModel.class);

        buttonStartTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //task pregenerato per testare la corretta esecuzione delle azioni

                ArrayList<Action> actions = new ArrayList<>();

                actions.add(new changeTextAction(textViewText,"test1", getContext()));
                actions.add(new changeTextAction(textViewText,"test2", getContext()));

                Task task = new Task(0, actions, "test1", null);

                try {
                    task.startTask();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        buttonStartCustomTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(taskHelper.getTaskBuffer() != null){
                    try {
                        taskHelper.getTaskBuffer().startTask();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    Log.e("TasK", "task is null or missing");
                }
            }
        });

        return view;
    }
}