package com.lock.newtemiactionsystemtest.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.fragments.NetworkFragment;
import com.lock.newtemiactionsystemtest.fragments.TaskFragment;
import com.lock.newtemiactionsystemtest.fragments.TaskGeneratorFragment;
import com.lock.newtemiactionsystemtest.tasks.Task;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button taskButton, networkButton, taskMakerButton;
    Task testTask;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        initViews();

        fragmentManager = getSupportFragmentManager();

        setTabButtonListeners();

    }


    public void setTabButtonListeners(){

        taskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle args = new Bundle();
                args.putSerializable("customTask", testTask);
                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView, TaskFragment.class, args)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        networkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView, NetworkFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        taskMakerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerView, TaskGeneratorFragment.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });


    }

    public void setTestTask(Task testTask) {
        this.testTask = testTask;
    }

    public void initViews(){
        networkButton = findViewById(R.id.networkButton);
        taskButton = findViewById(R.id.taskButton);
        taskMakerButton = findViewById(R.id.taskMakerButton);
    }
}