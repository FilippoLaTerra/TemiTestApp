package com.lock.newtemiactionsystemtest.fragments;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.lock.newtemiactionsystemtest.R;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * this was a a test page for the network functionalities
 * used to open a local socket and connect to a remote socket
 */
public class NetworkFragment extends Fragment {

    final static int PORT = 6666;
    final String SERVER_IP = "192.168.1.110";
    private String ip;
    String line = null;
    Boolean isServerRunning = false;
    Boolean isClientRunning = false;
    Button buttonGetIp, buttonOpenServer, buttonCloseServer, buttonOpenClient, buttonCloseClient, buttonSendToServer;
    TextView log;
    EditText editTextMessage;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public NetworkFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NetworkFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NetworkFragment newInstance(String param1, String param2) {
        NetworkFragment fragment = new NetworkFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_network, container, false);
        log = view.findViewById(R.id.log);
        buttonGetIp = view.findViewById(R.id.buttonGetIp);
        buttonOpenServer = view.findViewById(R.id.buttonOpenServer);
        buttonCloseServer = view.findViewById(R.id.buttonCloseServer);
        buttonOpenClient = view.findViewById(R.id.buttonOpenClient);
        buttonCloseClient = view.findViewById(R.id.buttonCloseClient);
        buttonSendToServer = view.findViewById(R.id.buttonSendToServer);
        editTextMessage = view.findViewById(R.id.editTextMessage);

        if (ip == null) {
            Context context = requireContext().getApplicationContext();
            WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            ip = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        }

        buttonGetIp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                log.append("\nDevice IP address: " + ip);
            }
        });

        buttonOpenServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isServerRunning){
                    log.append("\nServer already running on port: " + PORT);
                } else {
                    ServerThread serverThread = new ServerThread();
                    serverThread.start();
                }
            }
        });

        buttonOpenClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isClientRunning){
                    log.append("\nClient already running for IP: " + SERVER_IP + " on Port: " + PORT);
                } else {
                    ClientThread clientThread = new ClientThread();
                    clientThread.start();
                }
            }
        });

        buttonSendToServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                line = String.valueOf(editTextMessage.getText());

            }
        });

        buttonCloseServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isServerRunning = false;
            }
        });

        buttonCloseClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isClientRunning = false;
            }
        });

        return view;
    }


    class ServerThread extends Thread {

        @Override
        public void run() {

            Server server = new Server(PORT);

        }

    }

    class ClientThread extends Thread{
        public void run() {

            Client client = new Client(SERVER_IP, PORT);


        }
    }

    public class Server{

        Socket socket;
        ServerSocket server;
        DataInputStream in;

        public Server(int port){
            try {
                server = new ServerSocket(port);
                isServerRunning = true;
                logData("Server Started");
                logData("waiting for a client");
                socket = server.accept();

                logData("Client Accepted");

                in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));

                String line = "";

                while(isServerRunning) {
                    try {
                        line = in.readUTF();
                        logData(line);
                    } catch(IOException i) {
                        Log.e("IOException", String.valueOf(i));
                        logData(String.valueOf(i));
                    }
                }

                logData("closing connection");

            }catch (IOException i) {
                Log.e("IOException", String.valueOf(i));
                logData(String.valueOf(i));
            }
        }

        public void logData(String line){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    log.append("\n" + line);
                }
            });
        }

    }


    public class Client {

        private Socket socket;
        private BufferedReader input;
        private DataOutputStream out;

        public Client(String address, int port) {

            try {
                isClientRunning = true;
                socket = new Socket(address, port);
                logData("connected");

                input = new BufferedReader(new InputStreamReader(System.in));

                out = new DataOutputStream(socket.getOutputStream());

            } catch (UnknownHostException u) {
                Log.e("UnknownHostException", String.valueOf(u));
                logData(String.valueOf(u));
            } catch (IOException i) {
                Log.e("IOException", String.valueOf(i));
                logData(String.valueOf(i));
            }



            while (isClientRunning) {

                try {

                    if(line != null){
                        out.writeUTF(line);
                        line = null;
                    }

                } catch(IOException i) {
                    Log.e("IOException", String.valueOf(i));
                    logData(String.valueOf(i));
                }

            }

            try {
                input.close();
                out.close();
                socket.close();
            } catch (IOException i) {
                Log.e("IOException", String.valueOf(i));
                logData(String.valueOf(i));
            }
        }

        public void logData(String line){
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    log.append("\n" + line);
                }
            });
        }

    }



}
