package com.lock.newtemiactionsystemtest.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.lock.newtemiactionsystemtest.ActionBuilderViewModel;
import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.actions.changeTextAction;
import com.lock.newtemiactionsystemtest.helpers.TaskHelper;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EditChangeTextFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EditChangeTextFragment extends Fragment {

    private static final String ACTION_KEY = "action_key";
    private EditText editTextTextActionText;
    private Button buttonConfirmText;
    private changeTextAction action;
    int actionPosition;
    ArrayList<Action> customTaskActions;
    public EditChangeTextFragment() {
        // Required empty public constructor
    }

    public static EditChangeTextFragment newInstance(String param1) {
        EditChangeTextFragment fragment = new EditChangeTextFragment();
        Bundle args = new Bundle();
        args.putString(ACTION_KEY, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            action = (changeTextAction) getArguments().getSerializable(ACTION_KEY);
            actionPosition = getArguments().getInt("position_key");
            customTaskActions = (ArrayList<Action>) getArguments().getSerializable("actionsList");

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit_change_text, container, false);

        editTextTextActionText = view.findViewById(R.id.editTextTextActionText);
        buttonConfirmText = view.findViewById(R.id.buttonConfirmText);

        buttonConfirmText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.setText(String.valueOf(editTextTextActionText.getText()));
                customTaskActions.set(actionPosition, action);
                TaskHelper taskHelper = TaskHelper.getInstance();
                taskHelper.customTaskActions = customTaskActions;
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}