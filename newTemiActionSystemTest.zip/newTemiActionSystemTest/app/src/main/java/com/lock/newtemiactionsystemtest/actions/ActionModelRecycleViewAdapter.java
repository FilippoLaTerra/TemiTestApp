package com.lock.newtemiactionsystemtest.actions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.RecyclerViewInterface;

import java.util.ArrayList;

public class ActionModelRecycleViewAdapter extends RecyclerView.Adapter<ActionModelRecycleViewAdapter.MyViewHolder>{

    private final RecyclerViewInterface recyclerViewInterface;
    Context context;
    ArrayList<ActionModel> actions;

    public ActionModelRecycleViewAdapter(Context context, ArrayList<ActionModel> actions, RecyclerViewInterface recyclerViewInterface){
        this.recyclerViewInterface = recyclerViewInterface;
        this.context = context;
        this.actions = actions;

    }

    @NonNull
    @Override
    public ActionModelRecycleViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyclerview_action, parent, false);

        return new ActionModelRecycleViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.ID.setText( Integer.toString(actions.get(position).action_id));
        holder.name.setText(actions.get(position).action_name);

    }


    @Override
    public int getItemCount() {
        return actions.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name;
        TextView ID;

        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.textViewActionName);
            ID = itemView.findViewById(R.id.textViewActionId);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();

                        if( position != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
