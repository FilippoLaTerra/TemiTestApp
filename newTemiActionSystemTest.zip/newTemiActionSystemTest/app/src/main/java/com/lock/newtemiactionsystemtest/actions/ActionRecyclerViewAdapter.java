package com.lock.newtemiactionsystemtest.actions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lock.newtemiactionsystemtest.R;
import com.lock.newtemiactionsystemtest.RecyclerViewInterface;

import java.util.ArrayList;

public class ActionRecyclerViewAdapter extends RecyclerView.Adapter<ActionRecyclerViewAdapter.MyViewHolder>{

    private final RecyclerViewInterface recyclerViewInterface;
    Context context;
    ArrayList<Action> actions;

    public ActionRecyclerViewAdapter(Context context, ArrayList<Action> actions, RecyclerViewInterface recyclerViewInterface){
        this.recyclerViewInterface = recyclerViewInterface;
        this.context = context;
        this.actions = actions;

    }

    @NonNull
    @Override
    public ActionRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyclerview_action_complex, parent, false);

        return new ActionRecyclerViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.description.setText(actions.get(position).action_description);
        holder.name.setText(actions.get(position).action_name);

    }


    @Override
    public int getItemCount() {
        return actions.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name;
        TextView description;
        Button buttonEditAction, buttonInfoAction, buttonRemoveAction;

        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            name = itemView.findViewById(R.id.textViewActionNameComplex);
            description = itemView.findViewById(R.id.textViewActionDescription);
            buttonEditAction = itemView.findViewById(R.id.buttonEditAction);
            buttonInfoAction = itemView.findViewById(R.id.buttonInfoAction);
            buttonRemoveAction = itemView.findViewById(R.id.buttonRemoveAction);

            buttonEditAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();

                        if( position != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onEditButtonClick(position);
                        }
                    }
                }
            });

            buttonInfoAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();

                        if( position != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onInfoButtonClick(position);
                        }
                    }
                }
            });

            buttonRemoveAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int position = getAdapterPosition();

                        if( position != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onRemoveButtonClick(position);
                        }
                    }
                }
            });
        }
    }
}
