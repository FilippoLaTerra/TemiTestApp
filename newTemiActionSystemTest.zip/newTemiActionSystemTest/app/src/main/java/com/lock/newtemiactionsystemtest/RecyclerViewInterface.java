package com.lock.newtemiactionsystemtest;

public interface RecyclerViewInterface {

    void onItemClick(int position);
    void onEditButtonClick(int position);
    void onInfoButtonClick(int position);
    void onRemoveButtonClick(int position);
}
