package com.lock.newtemiactionsystemtest.actions;

public class ActionModel {

    public int action_id;
    public String action_name;
    public String action_description;

    public ActionModel(int action_id, String action_name, String action_description) {
        this.action_id = action_id;
        this.action_name = action_name;
        this.action_description = action_description;
    }
}
