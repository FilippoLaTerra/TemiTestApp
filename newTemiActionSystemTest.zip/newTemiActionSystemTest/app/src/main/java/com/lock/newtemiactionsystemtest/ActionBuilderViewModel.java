package com.lock.newtemiactionsystemtest;

import android.util.Log;

import androidx.lifecycle.ViewModel;

import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.tasks.Task;

import java.util.ArrayList;

public class ActionBuilderViewModel extends ViewModel {

    public ArrayList<Action> customTaskActions;
    public Task customTask;
    public int actionToEditPosition;

    public ActionBuilderViewModel() {
        Log.i("ACTION BUILDER", "Viewmodel created");
        this.customTaskActions = new ArrayList<>();
    }
}
