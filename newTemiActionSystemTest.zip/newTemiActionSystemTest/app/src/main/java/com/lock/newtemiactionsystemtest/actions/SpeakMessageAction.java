package com.lock.newtemiactionsystemtest.actions;

import android.os.Parcel;
import android.util.Log;

import androidx.annotation.NonNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lock.newtemiactionsystemtest.fragments.EditSpeakMessageFragment;

/**
 * @author Filippo La Terra Maggiore
 * @version 1.0
 * ùAction that handles temi TTS service
 *(currently missing the temi implemetation,
 * implementing the sdk on a non temi device will freeze the device)
 */
@JsonIgnoreProperties(value = { "actionName" })
public class SpeakMessageAction extends Action{

    protected String message;
    protected String language;

    public SpeakMessageAction(){
        super(103, "SpeakMessage", "placeholder");
        this.actionEditorClass = EditSpeakMessageFragment.class;
    }

    /**
     *
     * @param message
     * the message that temi needs to say
     * @param language
     * the language for the message, if null it uses the default language specified in the settings
     */
    public SpeakMessageAction(@NonNull String message, String language) {
        super(103);
        this.actionEditorClass = EditSpeakMessageFragment.class;

        if(message.equals("")){
            //handles error
        } else {
            this.message = message;
        }

        if(language != null){
            if(language.equals("")){
                this.language = settingsHelper.getDefaultLanguage();
            } else {
                this.language = language;
            }
        } else {
            this.language = settingsHelper.getDefaultLanguage();
        }

    }

    @Override
    public void start() {
        this.isRunning = true;
        Log.i("Action", "Speak message started");
        speakMessage(message, language);
    }

    @Override
    public void stop() {

    }

    @Override
    public synchronized void onComplete() {



        Log.i("Action", "Action completed");
        this.isRunning = false;
        notifyAll();
    }

    private void speakMessage(String message, String language){


    }

    /**
     * WIP
     * converts the language specification from string to temi's language code.
     * @param language
     * @return
     */
    private int getLanguageCode(String language){
        //TODO -> update with temi's Language enum class
        switch(language){
            case "IT": return 19;
            default : return 0;
        }
    }

    @Override
    protected void doPost() {

    }

    @Override
    public synchronized void onError() {
        Log.e("TTS", "An error with the TTS has occurred");
        this.isRunning = false;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    @Override
    public String toString() {
        return "SpeakMessageAction{" +
                "action_id=" + action_id +
                ", message='" + message + '\'' +
                ", language='" + language + '\'' +
                '}';
    }

}
