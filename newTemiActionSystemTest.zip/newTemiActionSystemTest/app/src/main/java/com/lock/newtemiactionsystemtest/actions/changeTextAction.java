package com.lock.newtemiactionsystemtest.actions;

import android.content.Context;
import android.os.Parcel;
import android.util.Log;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.lock.newtemiactionsystemtest.fragments.EditChangeTextFragment;

import java.io.Serializable;

/**
 * test action for development purposes
 */
public class changeTextAction extends Action implements Serializable {

    private TextView textview;
    private String text;
    private Context context;

    public changeTextAction() {
        super(902, "changeText", "placeholder");
        this.actionEditorClass = EditChangeTextFragment.class;
    }

    public changeTextAction(TextView textbox, String text, Context context) {
        super(0);
        this.textview = textbox;
        this.text = text;
        this.context = context;
        this.actionEditorClass = EditChangeTextFragment.class;
    }

    @Override
    public void start() {
        this.isRunning = true;
        Log.i("ACTION", "change text action started");

        if(actionListener != null){


        try{
            ContextCompat.getMainExecutor(context).execute(()  -> {

                if(textview != null)
                    textview.setText(text);
                this.onComplete();
                actionListener.onComplete();
            });
        } catch (Exception e) {
            Log.i("ACTION", String.valueOf(e));
        }
        }
    }

    @Override
    public void stop() {

    }

    @Override
    public void onComplete() {
        this.isRunning = false;
        Log.i("CHANGETEXT", "finito :)");
    }

    @Override
    protected void doPost() {

    }

    @Override
    public void onError() {

    }

    public void setTextview(TextView textview) {
        this.textview = textview;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}
