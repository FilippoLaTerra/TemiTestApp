package com.lock.newtemiactionsystemtest.helpers;

import com.lock.newtemiactionsystemtest.actions.Action;
import com.lock.newtemiactionsystemtest.tasks.Task;

import java.util.ArrayList;

public class TaskHelper {

    private static final TaskHelper instance = new TaskHelper();

    private Task taskBuffer;
    public ArrayList<Action> customTaskActions;

    // private constructor to avoid client applications using the constructor
    private TaskHelper(){}

    public static TaskHelper getInstance() {
        return instance;
    }

    public Task getTaskBuffer() {
        return taskBuffer;
    }

    public void setTaskBuffer(Task taskBuffer) {
        this.taskBuffer = taskBuffer;
    }
}
