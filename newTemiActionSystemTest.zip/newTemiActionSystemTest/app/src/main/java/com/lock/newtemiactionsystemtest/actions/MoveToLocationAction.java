package com.lock.newtemiactionsystemtest.actions;

import android.os.Parcel;
import android.util.Log;

import androidx.annotation.NonNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lock.newtemiactionsystemtest.fragments.EditMoveToActionFragment;

/**
 * @author Filippo La Terra Maggiore
 * @version 1.0
 * This action class handles the Robot Temi movement
 * (currently missing the temi implemetation,
 * implementing the sdk on a non temi device will freeze the device)
 */
@JsonIgnoreProperties(value = { "actionName" })
public class MoveToLocationAction extends Action{

    protected String location;
    protected boolean backwards;
    protected int speed;
    protected String custom_fallback;
    //protected Robot robot;

    public MoveToLocationAction(){
        super(102, "moveToLocation", "placeholder");
        this.actionEditorClass = EditMoveToActionFragment.class;
        //this.robot = Robot.getInstance();
    }
    public MoveToLocationAction(@NonNull String location, Boolean backwards, String speed, String custom_fallback) {
        super(102);
        this.actionEditorClass = EditMoveToActionFragment.class;
        //this.robot = Robot.getInstance();

        if(location.equals("")){
            onError();
        } else {
            this.location = location;
        }

        if(backwards == null){
            this.backwards = false; //should get default parameter from settings
        } else {
            this.backwards = backwards;
        }

        if(custom_fallback != null){
            if(custom_fallback.equals("")){
                onError();
            }
        }
    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

        Log.i("ACTION", "action stopped");
    }

    @Override
    public void onComplete() {
        this.isRunning = false;
        Log.i("GOTO", "arrived at destination");

    }

    @Override
    protected void doPost() {

    }

    @Override
    public void onError() {
        this.isRunning = false;
        Log.i("GOTO", "An error has occurred or the user aborted the action");
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isBackwards() {
        return backwards;
    }

    public void setBackwards(boolean backwards) {
        this.backwards = backwards;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getCustom_fallback() {
        return custom_fallback;
    }

    public void setCustom_fallback(String custom_fallback) {
        this.custom_fallback = custom_fallback;
    }

    @NonNull
    @Override
    public String toString() {
        return "MoveToLocationAction{" +
                "action_id=" + action_id +
                ", location='" + location + '\'' +
                ", backwards=" + backwards +
                ", speed=" + speed +
                ", custom_fallback='" + custom_fallback + '\'' +
                '}';
    }

}

