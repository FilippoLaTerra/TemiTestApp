package com.lock.newtemiactionsystemtest.actions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;

import com.lock.newtemiactionsystemtest.ActionBuilderViewModel;
import com.lock.newtemiactionsystemtest.ActionListenerInterface;
import com.lock.newtemiactionsystemtest.Activities.ActionEditor;
import com.lock.newtemiactionsystemtest.helpers.SettingsHelper;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author Filippo La Terra Maggiore
 * @version 1.0
 * The Action abstract class defines a basic instruction to be executed
 * allowing for better customization and management of any desired process
 */
public abstract class Action implements Serializable, ActionListenerInterface{

    public final int action_id;
    public String action_name;
    public String action_description;
    protected SettingsHelper settingsHelper;
    protected Class actionEditorClass;
    public boolean isRunning;
    protected ActionListenerInterface actionListener;


    //for debug purposes
    public Action(int action_id, String action_name, String action_description) {
        this(action_id);
        this.action_name = action_name;
        this.action_description = action_description;
    }

    /**
     * @param action_id
     */
    public Action(int action_id) {
        this.action_id = action_id;
        this.settingsHelper = new SettingsHelper();
        this.actionListener = null;
        this.isRunning = false;
    }

    public void setListener(ActionListenerInterface listener) {
        this.actionListener = listener;
    }
    public ActionListenerInterface getActionListener() {
        return actionListener;
    }
    /**
     * Defines what happens when an action is started
     */
    public abstract void start();

    /**
     * Defines how an action is stopped safely
     */
    public abstract void stop();

    /**
     * Defines what an action does when it finishes its lifecycle
     */
    public abstract void onComplete();

    /**
     * Defines how and which data the action gets posted (WIP)
     */
    protected abstract void doPost();

    /**
     * Defines how the action handles errors
     */
    public abstract void onError();

    public Class Editor() {
        return actionEditorClass;
    }

    /**
     * Opens the action's editor activity (WIP)
     * @param context
     * context to start the view
     * @param parentactivity
     * parent activity that launches the view
     * @param position
     * the position of the action calling the editor in the array
     * @param customTaskActions
     * list of the actions in the array to correctly update the list
     */
    public void openEditor(Context context, Activity parentactivity, int position,  ArrayList<Action> customTaskActions){
        Intent intent = new Intent(parentactivity, ActionEditor.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("action",this);
        intent.putExtra("position", position);
        intent.putExtra("actionsList", customTaskActions);
        context.startActivity(intent);
    }
}
