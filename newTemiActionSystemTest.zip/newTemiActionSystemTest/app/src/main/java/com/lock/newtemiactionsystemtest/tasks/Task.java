package com.lock.newtemiactionsystemtest.tasks;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.lock.newtemiactionsystemtest.ActionListenerInterface;
import com.lock.newtemiactionsystemtest.ContextGetter;
import com.lock.newtemiactionsystemtest.actions.Action;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author Filippo La Terra Maggiore
 * @version 1.0
 * The task class consists of a series of actions to be executed on a dedicated thread,
 * it allows for the programming of said task on a specified date and time
 * and the ability to start, stop, pause and resume the task
 */

public class Task implements Serializable{

    public int task_id;
    public String taskName;
    protected ArrayList<Action> actions;
    protected Date programmedDate;
    protected Action currentAction;
    private int actionIndex = 0;
    private boolean isTaskRunning;

    private final ActionListenerInterface actionListener = new ActionListenerInterface() {
        @Override
        public void onComplete() {
            actionIndex++;
            if (actionIndex >= actions.size()){
                cancelTask();
            } else {
                currentAction = actions.get(actionIndex);
            }
            synchronized (taskTread){
                taskTread.notify();
            }


        }
        @Override
        public synchronized void onError() {
            Log.e("TASK", "The task has encountered an error");
            currentAction.onError();
            cancelTask();
        }
    };

    /**
     * The thread iterates through the available actions and starts them
     */
    private final Thread taskTread =  new Thread(){
        public void run(){
            while(isTaskRunning){

                if(currentAction == null){
                    currentAction = actions.get(actionIndex);
                }
                if(currentAction.getActionListener() == null){
                    currentAction.setListener(actionListener);
                }
                if(!currentAction.isRunning && isTaskRunning) {
                    currentAction.start();

                    synchronized (taskTread){
                        try {
                            taskTread.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }

                }
            }
        }
    };

    public Task(){
    }

    /**
     * This method sets a loremipsum
     * @param task_id loremipsum
     * @param taskName loremipsum
     * @param actions loremipsum
     * @param programmedDate loremipsum
     */
    public Task(int task_id, @NonNull ArrayList<Action> actions, String taskName, Date programmedDate) {
        this.task_id = task_id;
        this.taskName = taskName;
        this.actions = actions;
        this.programmedDate = programmedDate;
    }

    /**
     * This method sets a StartAlarm for the specified date
     * @param date the date and time at which the task must be started
     */
    public void programTask(Date date){
        Log.i("TASK","Programming task for " + date);

        Context context = ContextGetter.getContext();

        boolean alreadyProgrammed = PendingIntent.getBroadcast(context, this.task_id, new Intent("task.alarm"), PendingIntent.FLAG_NO_CREATE) != null;

        if(!alreadyProgrammed){
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, TaskAlarm.class);
            intent.setAction("task.alarm");

            //puts the task id and the task itself into the alarm intent
            byte[] taskByteArray = toByteArray();

            if(taskByteArray != null){
                intent.putExtra("task_id", this.task_id);
                intent.putExtra("task", toByteArray());
                PendingIntent pendingIntent = PendingIntent.getBroadcast(context, task_id, intent, PendingIntent.FLAG_ONE_SHOT);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, date.getTime(), pendingIntent);
            } else {
                Log.e("TASK_PROGRAMMING", "Task with id " + task_id + " generated a null byte array");
            }

        } else {
            Log.e("TASK", "Task with id " + task_id + " has already been programmed");
        }
    }

    /**
     * Starts the task
     */
    public void startTask() throws InterruptedException {
        if (!taskTread.isAlive()) {
            Log.i("TASK_THREAD", "Task with id " + task_id + " thread started");
            this.isTaskRunning = true;
            taskTread.start();

        } else {
            Log.i("TASK_THREAD", "Task with id " + task_id + " thread already running");
        }
        Log.i("THREAD", "isAlive?: " + taskTread.isAlive());
    }

    /**
     * Pauses the currently running task
     * @throws InterruptedException
     */
    public synchronized void pauseTask() throws InterruptedException {
        Log.i("TASK_THREAD", "Task " + task_id + " thread paused");

        synchronized (taskTread){
            taskTread.wait();
        }
    }

    /**
     * Starts the previously paused task
     */
    public synchronized void resumeTask(){
        Log.i("TASK_THREAD", "Task " + task_id + " thread resumed");
        synchronized (taskTread){
            taskTread.notify();
        }
    }

    /**
     *  Safely cancels the task, interrupting the current action and task thread
     *  if the task was programmed, it will cancel the corresponding alarm
     */
    public void cancelTask(){
        Log.d("TASK", "Canceling task");
        this.isTaskRunning = false;
        try {
            //taskTread.interrupt();
            if(currentAction != null)
                currentAction.stop();
        } catch (Exception e) {
            Log.e("TASK_CANCEL", "Task with id " + task_id + " failed to cancel, is there any task running? ");
        }

        if (this.programmedDate != null){
            try {
                Context context = ContextGetter.getContext();
                AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(context, TaskAlarm.class);
                intent.setAction("task.alarm");
                PendingIntent pendingIntent = PendingIntent.getBroadcast(context, task_id, intent, PendingIntent.FLAG_ONE_SHOT);
                alarmManager.cancel(pendingIntent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Log.i("THREAD", "isAlive: " + taskTread.isAlive());
    }

    /**
     * Customizable method to handle errors (WIP)
     */
    public void onError(){
        //personalized error handling
    }

    /**
     * converts the task object into a byte[]
     * @return
     */
    private byte[] toByteArray(){
        byte[] byteArray = null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(bos);
            out.writeObject(new Task(this.task_id, this.actions, this.taskName, this.programmedDate));
            out.flush();
            byteArray = bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException ex) {
                // ignore close exception
            }
        }
        return byteArray;
    }

    public ArrayList<Action> getActions() {
        return actions;
    }

    public void setActions(ArrayList<Action> actions) {
        this.actions = actions;
    }
}
